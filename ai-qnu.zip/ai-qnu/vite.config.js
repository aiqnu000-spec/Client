import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// /api/* được chuyển sang server Express (cổng 3001) khi chạy dev
export default defineConfig({
  plugins: [react()],
  server: { proxy: { "/api": "http://localhost:3001" } },
});
