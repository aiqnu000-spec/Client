// role: "user" | "bot". isLast = true thì hiện đuôi bong bóng (kiểu iOS)
export default function Bubble({ role, isLast, children }) {
  return (
    <div className={`row ${role}${isLast ? "" : " cont"}`}>
      <div className="bubble">
        {children || (
          <span className="dots"><i /><i /><i /></span>
        )}
      </div>
    </div>
  );
}
