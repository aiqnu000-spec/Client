export default function Modal({ title, children, confirmText = "Lưu", danger, error, onConfirm, onClose }) {
  return (
    <div className="modal" onClick={onClose}>
      <div className="mbox" onClick={(e) => e.stopPropagation()}>
        <h3>{title}</h3>
        {children}
        {error && <div className="error">{error}</div>}
        <div className="mbtn">
          <button onClick={onClose}>Hủy</button>
          <button className={danger ? "danger" : "primary-sm"} onClick={onConfirm}>{confirmText}</button>
        </div>
      </div>
    </div>
  );
}
