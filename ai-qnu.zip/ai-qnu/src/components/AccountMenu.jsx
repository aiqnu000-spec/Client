// Menu bật lên khi bấm vào khu tài khoản ở cuối sidebar
export default function AccountMenu({ theme, onProfile, onPassword, onToggleTheme, onExport, onClear, onLogout }) {
  return (
    <div className="pop">
      <button onClick={onProfile}>👤 Hồ sơ cá nhân</button>
      <button onClick={onPassword}>🔑 Đổi mật khẩu</button>
      <button onClick={onToggleTheme}>{theme === "dark" ? "☀️ Chế độ sáng" : "🌙 Chế độ tối"}</button>
      <hr />
      <button onClick={onExport}>📤 Xuất các cuộc trò chuyện</button>
      <button className="red" onClick={onClear}>🗑 Xóa tất cả cuộc trò chuyện</button>
      <hr />
      <button onClick={onLogout}>⎋ Đăng xuất</button>
    </div>
  );
}
