import { useEffect, useState } from "react";
import { ls } from "../lib/storage";
import { changePassword, updateName } from "../lib/auth";
import { streamChat } from "../lib/api";
import Sidebar from "./Sidebar";
import ChatWindow from "./ChatWindow";
import Modal from "./Modal";

// Component "cha": giữ toàn bộ state của các cuộc trò chuyện
export default function Chat({ user, theme, onToggleTheme, onUser, onLogout }) {
  const storeKey = "qnu_chats_" + user.email;
  const [chats, setChats] = useState(() => ls.get(storeKey, []));
  const [activeId, setActiveId] = useState(() => ls.get(storeKey, [])[0]?.id ?? null);
  const [busy, setBusy] = useState(false);
  const [open, setOpen] = useState(false);               // sidebar trên mobile
  const [collapsed, setCollapsed] = useState(() => ls.get("qnu_col", false));
  const [modal, setModal] = useState(null);              // "profile" | "pw" | "clear"
  const [form, setForm] = useState({});
  const [toast, setToast] = useState("");

  useEffect(() => { ls.set(storeKey, chats); }, [chats]);
  useEffect(() => { ls.set("qnu_col", collapsed); }, [collapsed]);

  const chat = chats.find((c) => c.id === activeId);
  const patch = (id, fn) => setChats((cs) => cs.map((c) => (c.id === id ? fn(c) : c)));
  const flash = (t) => { setToast(t); setTimeout(() => setToast(""), 2500); };

  /* ---------- gửi tin nhắn ---------- */
  async function send(text) {
    const userMsg = { role: "user", content: text };
    const botMsg = { role: "assistant", content: "" };
    const history = [...(chat?.msgs ?? []), userMsg];

    let id = activeId;
    if (!id) {
      id = "c" + Date.now();
      setChats((cs) => [{ id, title: text.slice(0, 40), msgs: [userMsg, botMsg] }, ...cs]);
      setActiveId(id);
    } else {
      patch(id, (c) => ({ ...c, msgs: [...c.msgs, userMsg, botMsg] }));
    }

    const setLast = (content) =>
      patch(id, (c) => {
        const msgs = c.msgs.slice();
        msgs[msgs.length - 1] = { role: "assistant", content };
        return { ...c, msgs };
      });

    setBusy(true);
    try {
      await streamChat(history, setLast);
    } catch (err) {
      setLast("Xin lỗi, không kết nối được server. Hãy kiểm tra server đã chạy chưa. (" + err.message + ")");
    }
    setBusy(false);
  }

  /* ---------- thao tác với danh sách chat ---------- */
  const newChat = () => { setActiveId(null); setOpen(false); };
  const select = (id) => { setActiveId(id); setOpen(false); };
  const pin = (id) => patch(id, (c) => ({ ...c, pin: !c.pin }));
  const rename = (id, title) => patch(id, (c) => ({ ...c, title }));
  const remove = (id) => {
    setChats((cs) => cs.filter((c) => c.id !== id));
    if (activeId === id) setActiveId(null);
  };

  /* ---------- menu tài khoản ---------- */
  const openModal = (name, init = {}) => { setForm(init); setModal(name); };
  const setField = (k) => (e) => setForm({ ...form, [k]: e.target.value, error: "" });

  function saveProfile() {
    const name = (form.a || "").trim();
    if (!name) return setForm({ ...form, error: "Tên không được để trống" });
    updateName(user.email, name);
    onUser({ ...user, name });
    setModal(null);
    flash("Đã cập nhật hồ sơ");
  }

  async function savePassword() {
    try {
      await changePassword(user.email, form.a || "", form.b || "");
      setModal(null);
      flash("Đã đổi mật khẩu");
    } catch (err) {
      setForm({ ...form, error: err.message });
    }
  }

  function clearAll() {
    setChats([]); setActiveId(null); setModal(null);
    flash("Đã xóa toàn bộ cuộc trò chuyện");
  }

  function exportAll() {
    if (!chats.length) return flash("Chưa có cuộc trò chuyện nào");
    const text = chats
      .map((c) => "# " + c.title + "\n\n" + c.msgs.map((m) => (m.role === "user" ? "Bạn: " : "AI_QNU: ") + m.content).join("\n\n"))
      .join("\n\n------\n\n");
    const url = URL.createObjectURL(new Blob([text], { type: "text/plain;charset=utf-8" }));
    const a = Object.assign(document.createElement("a"), { href: url, download: "AI_QNU_chats.txt" });
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="app">
      <div className={"scrim" + (open ? " open" : "")} onClick={() => setOpen(false)} />

      <Sidebar
        user={user} chats={chats} activeId={activeId} open={open} collapsed={collapsed}
        onCollapse={() => { setCollapsed(true); setOpen(false); }}
        onNew={newChat} onSelect={select} onPin={pin} onRename={rename} onDelete={remove}
        menuProps={{
          theme, onToggleTheme, onLogout,
          onProfile: () => openModal("profile", { a: user.name }),
          onPassword: () => openModal("pw"),
          onClear: () => openModal("clear"),
          onExport: exportAll,
        }}
      />

      <ChatWindow
        user={user} chat={chat} busy={busy} collapsed={collapsed}
        onOpenSidebar={() => { setOpen(true); setCollapsed(false); }}
        onSend={send}
      />

      {modal === "profile" && (
        <Modal title="Hồ sơ cá nhân" error={form.error} onConfirm={saveProfile} onClose={() => setModal(null)}>
          <input placeholder="Tên hiển thị" value={form.a || ""} onChange={setField("a")} />
          <div className="note left">{user.email}</div>
        </Modal>
      )}
      {modal === "pw" && (
        <Modal title="Đổi mật khẩu" error={form.error} onConfirm={savePassword} onClose={() => setModal(null)}>
          <input type="password" placeholder="Mật khẩu hiện tại" value={form.a || ""} onChange={setField("a")} />
          <input type="password" placeholder="Mật khẩu mới" value={form.b || ""} onChange={setField("b")} />
        </Modal>
      )}
      {modal === "clear" && (
        <Modal title="Xóa tất cả?" confirmText="Xóa hết" danger onConfirm={clearAll} onClose={() => setModal(null)}>
          <div className="note left">Toàn bộ cuộc trò chuyện sẽ bị xóa và không thể khôi phục.</div>
        </Modal>
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
