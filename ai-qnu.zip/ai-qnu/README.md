# AI_QNU

Web chat AI giao diện kiểu ChatGPT: React + Vite, bong bóng kiểu iOS, xanh dương/trắng, dark mode, đăng nhập.

## Chạy dự án (cần Node.js 18+)

Mở **2 terminal**:

```bash
# Terminal 1 – server giữ API key
cd server
npm install
cp .env.example .env      # rồi mở .env, dán ANTHROPIC_API_KEY của bạn
npm start

# Terminal 2 – giao diện React
npm install
npm run dev               # mở http://localhost:5173
```

Lấy API key tại https://console.anthropic.com. Không đưa key vào code React.

## Cấu trúc

```
src/
  App.jsx               Chọn Login hoặc Chat, quản lý theme
  styles.css            Biến màu, dark mode, bong bóng
  lib/                  storage.js, auth.js (demo), api.js (stream)
  components/
    Login.jsx  Chat.jsx  Sidebar.jsx  AccountMenu.jsx
    ChatWindow.jsx  Bubble.jsx  Modal.jsx
server/index.js         Express gọi Claude API (streaming)
```

## Lưu ý
- Đăng nhập hiện lưu trong localStorage (demo). Muốn tài khoản thật: dùng Firebase/Supabase Auth hoặc backend riêng.
- Triển khai: frontend lên Vercel/Netlify, server lên Render/Railway; đổi đường dẫn `/api/chat` trong `src/lib/api.js` thành URL server.
