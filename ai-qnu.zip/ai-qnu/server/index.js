import "dotenv/config";
import express from "express";
import cors from "cors";
import Anthropic from "@anthropic-ai/sdk";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const client = new Anthropic(); // tự đọc ANTHROPIC_API_KEY trong file .env
const MODEL = process.env.MODEL || "claude-sonnet-5-5";

const SYSTEM =
  "Bạn là AI_QNU, trợ lý AI thân thiện. Trả lời bằng ngôn ngữ của người dùng " +
  "(ưu tiên tiếng Việt), ngắn gọn, rõ ràng.";

app.post("/api/chat", async (req, res) => {
  const messages = (req.body.messages || [])
    .filter((m) => m && m.content)
    .map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: String(m.content) }));

  if (!messages.length || messages[messages.length - 1].role !== "user") {
    return res.status(400).json({ error: "Thiếu tin nhắn" });
  }

  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache");

  try {
    const stream = client.messages.stream({
      model: MODEL,
      max_tokens: 1024,
      system: SYSTEM,
      messages,
    });
    stream.on("text", (t) => res.write(t));
    await stream.finalMessage();
  } catch (err) {
    console.error(err);
    res.write("\n[Lỗi khi gọi AI: " + (err.message || "không rõ") + "]");
  }
  res.end();
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log("Server AI_QNU chạy ở http://localhost:" + PORT));
